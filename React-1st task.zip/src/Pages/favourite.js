function Favouritepage() {
  return <div>nikhil Soni</div>;
}

export default Favouritepage;
